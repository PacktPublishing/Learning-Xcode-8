//
//  ConfirmationInterfaceController.swift
//  Snippets
//
//  Created by Jak Tiano on 9/26/16.
//  Copyright © 2016 PacktPub. All rights reserved.
//

import WatchKit
import Foundation

class ConfirmationContext {
    let textString : String
    let confirmAction: (String) -> Void
    let tryAgainAction: () -> Void
    
    init (textString: String, confirmAction: @escaping (String) -> Void, tryAgainAction: @escaping () -> Void) {
        self.textString = textString
        self.confirmAction = confirmAction
        self.tryAgainAction = tryAgainAction
    }
}


class ConfirmationInterfaceController: WKInterfaceController {

    @IBOutlet var resultsLabel: WKInterfaceLabel!
    
    var currentContext: ConfirmationContext?
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        if let c = context as? ConfirmationContext {
            currentContext = c
            resultsLabel.setText(c.textString)
        }
    }

    @IBAction func confirmText() {
        popToRootController()
        if let context = currentContext {
            context.confirmAction(context.textString)
        }
    }
    
    @IBAction func tryAgain() {
        popToRootController()
        if let context = currentContext {
            context.tryAgainAction()
        }
    }

    @IBAction func cancel() {
        popToRootController()
    }
}
